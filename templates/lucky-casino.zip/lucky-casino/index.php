<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>LuckySpin — Online Slots &amp; Jackpots</title>
<meta name="description" content="LuckySpin — 500+ slot games, instant payouts and a jackpot that never stops climbing.">

<style></style>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Anton&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">

</head>
<body>

<!-- ============================= HEADER ============================= -->
<header id="site-header">
  <div class="container nav-row">
    <a href="#hero" class="logo"><span class="logo-mark">7</span>Lucky<span class="accent">Spin</span></a>

    <nav class="nav-links" id="navLinks">
      <a href="#hero">Home</a>
      <a href="#games">Slots</a>
      <a href="#jackpot">Jackpot</a>
      <a href="#faq">FAQ</a>
      <a href="#cta">VIP Club</a>
    </nav>

    <div class="nav-actions">
      <a href="#" class="btn btn-ghost btn-sm">Log In</a>
      <a href="#" class="btn btn-primary btn-sm">Join Now</a>
      <button class="nav-toggle" id="navToggle" aria-label="Toggle menu" aria-expanded="false"><span></span></button>
    </div>
  </div>
</header>

<!-- ============================= HERO ============================= -->
<section id="hero">
  <div class="container hero-grid">
    <div class="hero-copy">
      <span class="eyebrow">500+ Slots · Live 24/7</span>
      <h1>Spin Into The Jackpot Zone</h1>
      <p>New slots drop weekly, payouts land in minutes, and the jackpot pool climbs with every spin on the site. Pull the lever — your run starts here.</p>
      <div class="hero-actions">
        <a href="#games" class="btn btn-primary">Play Now</a>
        <a href="#games" class="btn btn-ghost">Browse Slots</a>
      </div>
      <div class="hero-meta">
        <div><strong>$2.4M</strong><span>Paid this week</span></div>
        <div><strong>50K+</strong><span>Active players</span></div>
        <div><strong>4.9/5</strong><span>Player rating</span></div>
      </div>
    </div>

    <div class="hero-visual">
      <div class="slot-machine">
        <div class="reels">
          <div class="reel"><div class="reel-strip"><span>7️⃣</span><span>💎</span><span>🍒</span><span>⭐</span><span>7️⃣</span><span>💎</span><span>🍒</span><span>⭐</span></div></div>
          <div class="reel"><div class="reel-strip"><span>🍋</span><span>7️⃣</span><span>💎</span><span>🔔</span><span>🍋</span><span>7️⃣</span><span>💎</span><span>🔔</span></div></div>
          <div class="reel"><div class="reel-strip"><span>💎</span><span>⭐</span><span>7️⃣</span><span>🍒</span><span>💎</span><span>⭐</span><span>7️⃣</span><span>🍒</span></div></div>
        </div>
        <div class="slot-lever"></div>
        <div class="slot-payline">
          <span class="win">Last win <span class="amt">$1,240</span></span>
          <span class="pulse-dot" aria-hidden="true"></span>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ============================= STATS ============================= -->
<section id="stats">
  <div class="container stats-grid">
    <div class="stat"><h3>500+</h3><span>Slot Titles</span></div>
    <div class="stat"><h3>2 Min</h3><span>Avg. Payout Time</span></div>
    <div class="stat"><h3>96.8%</h3><span>Avg. RTP</span></div>
    <div class="stat"><h3>24/7</h3><span>Live Support</span></div>
  </div>
</section>

<!-- ============================= FEATURES ============================= -->
<section class="section" id="features">
  <div class="container">
    <div class="section-head center" style="margin-left:auto;margin-right:auto;">
      <span class="eyebrow">Why Players Stay</span>
      <h2>Built For Players Who Play To Win</h2>
      <p>No stalling on withdrawals, no fine print tricks — just fast, fair, secure play from your first spin.</p>
    </div>

    <div class="features-grid">
      <div class="feature-card">
        <div class="feature-icon">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>
        </div>
        <h3>Instant Payouts</h3>
        <p>Withdrawals are reviewed and released in minutes, not days — track every payout in real time.</p>
      </div>
      <div class="feature-card">
        <div class="feature-icon">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
        </div>
        <h3>Licensed &amp; Secure</h3>
        <p>Fully licensed operations with bank-grade encryption on every transaction and account.</p>
      </div>
      <div class="feature-card">
        <div class="feature-icon">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"></circle><circle cx="12" cy="12" r="1.5" fill="currentColor" stroke="none"></circle><circle cx="8.5" cy="9" r="1" fill="currentColor" stroke="none"></circle><circle cx="15.5" cy="9" r="1" fill="currentColor" stroke="none"></circle><circle cx="8.5" cy="15" r="1" fill="currentColor" stroke="none"></circle><circle cx="15.5" cy="15" r="1" fill="currentColor" stroke="none"></circle></svg>
        </div>
        <h3>Provably Fair</h3>
        <p>Every reel outcome is independently audited, with results and odds published for each game.</p>
      </div>
      <div class="feature-card">
        <div class="feature-icon">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"></circle><polyline points="12 7 12 12 16 14"></polyline></svg>
        </div>
        <h3>Round-The-Clock Support</h3>
        <p>Live chat is staffed day and night, so questions about a spin or a withdrawal never wait long.</p>
      </div>
    </div>
  </div>
</section>

<!-- ============================= GAMES ============================= -->

<section class="section section-alt" id="games">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">This Week's Lineup</span>
      <h2>Top Slots Right Now</h2>
      <p>Fresh releases, classic reels, and progressive titles feeding the jackpot pool below.</p>
    </div>

    <div class="games-grid">

      <div class="game-card">
        <div class="game-thumb">
          <span class="tag">New</span>
          <img
                  class="gen-image"
                  src="<?php echo get_template_directory_uri(); ?>"
                  alt="Diamond Cascade"
                  style="width:100%;height:100%;object-fit:cover;display:block;"
          >
        </div>
        <div class="game-body">
          <h3>Diamond Cascade</h3>
          <div class="game-meta">
            <span>RTP 97.1%</span>
            <span>Progressive</span>
          </div>
          <a href="#" class="btn btn-primary btn-sm btn-block">Play</a>
        </div>
      </div>

      <div class="game-card">
        <div class="game-thumb">
          <span class="tag">Hot</span>
          <img
                  class="gen-image"
                  src="<?php echo get_template_directory_uri(); ?>"
                  alt="Golden Reel Frenzy"
                  style="width:100%;height:100%;object-fit:cover;display:block;"
          >
        </div>
        <div class="game-body">
          <h3>Golden Reel Frenzy</h3>
          <div class="game-meta">
            <span>RTP 96.4%</span>
            <span>Classic</span>
          </div>
          <a href="#" class="btn btn-primary btn-sm btn-block">Play</a>
        </div>
      </div>

      <div class="game-card">
        <div class="game-thumb">
          <img
                  class="gen-image"
                  src="<?php echo get_template_directory_uri(); ?>"
                  alt="Wild Harvest"
                  style="width:100%;height:100%;object-fit:cover;display:block;"
          >
        </div>
        <div class="game-body">
          <h3>Wild Harvest</h3>
          <div class="game-meta">
            <span>RTP 96.9%</span>
            <span>Bonus Buy</span>
          </div>
          <a href="#" class="btn btn-primary btn-sm btn-block">Play</a>
        </div>
      </div>

      <div class="game-card">
        <div class="game-thumb">
          <span class="tag">Jackpot</span>
          <img
                  class="gen-image"
                  src="<?php echo get_template_directory_uri(); ?>"
                  alt="Neon Fortune"
                  style="width:100%;height:100%;object-fit:cover;display:block;"
          >
        </div>
        <div class="game-body">
          <h3>Neon Fortune</h3>
          <div class="game-meta">
            <span>RTP 97.6%</span>
            <span>Progressive</span>
          </div>
          <a href="#" class="btn btn-primary btn-sm btn-block">Play</a>
        </div>
      </div>

      <div class="game-card">
        <div class="game-thumb">
          <img
                  class="gen-image"
                  src="<?php echo get_template_directory_uri(); ?>"
                  alt="Midnight Roulette"
                  style="width:100%;height:100%;object-fit:cover;display:block;"
          >
        </div>
        <div class="game-body">
          <h3>Midnight Roulette</h3>
          <div class="game-meta">
            <span>RTP 97.3%</span>
            <span>Table</span>
          </div>
          <a href="#" class="btn btn-primary btn-sm btn-block">Play</a>
        </div>
      </div>

      <div class="game-card">
        <div class="game-thumb">
          <span class="tag">Hot</span>
          <img
                  class="gen-image"
                  src="<?php echo get_template_directory_uri(); ?>"
                  alt="Cosmic Sevens"
                  style="width:100%;height:100%;object-fit:cover;display:block;"
          >
        </div>
        <div class="game-body">
          <h3>Cosmic Sevens</h3>
          <div class="game-meta">
            <span>RTP 96.2%</span>
            <span>Classic</span>
          </div>
          <a href="#" class="btn btn-primary btn-sm btn-block">Play</a>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- ============================= JACKPOT BANNER ============================= -->
<section class="section" style="padding-top:0;">
  <div id="jackpot">
    <div class="jackpot-copy">
      <span class="eyebrow">Progressive Pool</span>
      <div class="jackpot-amount" id="jackpotAmount">$128,430</div>
      <p>Every spin across the site feeds the pool. It drops before midnight — be at the reels when it does.</p>
    </div>
    <div class="countdown" id="countdown">
      <div class="box"><strong id="cdHours">00</strong><span>Hours</span></div>
      <div class="box"><strong id="cdMins">00</strong><span>Mins</span></div>
      <div class="box"><strong id="cdSecs">00</strong><span>Secs</span></div>
    </div>
  </div>
</section>

<!-- ============================= FAQ ============================= -->
<section class="section section-alt" id="faq">
  <div class="container">
    <div class="section-head center" style="margin-left:auto;margin-right:auto;">
      <span class="eyebrow">Good To Know</span>
      <h2>Frequently Asked Questions</h2>
    </div>

    <div class="faq-list">
      <details class="faq-item" open>
        <summary>How do I create an account?</summary>
        <p class="faq-a">Tap Join Now, confirm your email, and set a payment method — most players are spinning within two minutes.</p>
      </details>
      <details class="faq-item">
        <summary>How fast are withdrawals processed?</summary>
        <p class="faq-a">Most withdrawals are reviewed and released within minutes; larger amounts may take a few hours for verification.</p>
      </details>
      <details class="faq-item">
        <summary>Are the games fair?</summary>
        <p class="faq-a">Every title runs on an independently audited random number generator, with published RTP for each game.</p>
      </details>
      <details class="faq-item">
        <summary>What payment methods are supported?</summary>
        <p class="faq-a">Cards, bank transfer, and major e-wallets are all supported for both deposits and withdrawals.</p>
      </details>
      <details class="faq-item">
        <summary>Can I play on mobile?</summary>
        <p class="faq-a">The site is fully responsive — no app download required, just open it in your mobile browser.</p>
      </details>
    </div>
  </div>
</section>

<!-- ============================= CTA / SIGNUP ============================= -->
<section id="cta">
  <div class="container">
    <span class="eyebrow" style="justify-content:center;display:flex;">Don't Miss A Drop</span>
    <h2>Get Notified When The Jackpot Hits</h2>
    <p>New game launches and jackpot alerts, straight to your inbox — no spam, unsubscribe any time.</p>
    <form class="cta-form" onsubmit="return false;">
      <input type="email" placeholder="Enter your email" required>
      <button type="submit" class="btn btn-primary">Notify Me</button>
    </form>
  </div>
</section>

<!-- ============================= FOOTER ============================= -->
<footer id="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div class="footer-brand">
        <a href="#hero" class="logo"><span class="logo-mark">7</span>Lucky<span class="accent">Spin</span></a>
        <p>500+ licensed slot titles, instant payouts, and a jackpot pool that grows with every spin on the site.</p>
        <div class="social-row">
          <a href="#" aria-label="Twitter"><svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M22 5.9c-.7.3-1.5.6-2.3.7.8-.5 1.5-1.3 1.8-2.3-.8.5-1.7.8-2.6 1a4.1 4.1 0 0 0-7 3.7A11.6 11.6 0 0 1 3.4 4.6a4.1 4.1 0 0 0 1.3 5.5c-.7 0-1.3-.2-1.9-.5v.1c0 2 1.4 3.6 3.3 4a4.1 4.1 0 0 1-1.9.1 4.1 4.1 0 0 0 3.8 2.8A8.2 8.2 0 0 1 2 18.4a11.6 11.6 0 0 0 6.3 1.8c7.5 0 11.7-6.3 11.7-11.7v-.5c.8-.6 1.5-1.3 2-2.1z"></path></svg></a>
          <a href="#" aria-label="Instagram"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="5"></rect><circle cx="12" cy="12" r="4"></circle><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"></circle></svg></a>
          <a href="#" aria-label="Discord"><svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M20 6.5c-1.4-.7-2.9-1.1-4.5-1.4l-.2.4c1.4.4 2.6.9 3.8 1.6-2.6-1.2-5.4-1.8-8.2-1.8s-5.6.6-8.2 1.8c1.2-.7 2.5-1.2 3.9-1.6l-.2-.4C5 5.4 3.5 5.8 2.1 6.5.6 11 .1 15.3.3 19.6c1.8 1.3 3.6 2.1 5.3 2.6l.7-1.1c-.9-.3-1.7-.7-2.5-1.3.2.2.4.3.6.4 4.3 2 9 2 13.3 0l.6-.4c-.8.6-1.6 1-2.5 1.3l.7 1.1c1.7-.5 3.5-1.3 5.3-2.6.3-5-.9-9.2-3.8-13.1zM8.6 15.7c-1 0-1.8-.9-1.8-2s.8-2 1.8-2 1.9.9 1.8 2c0 1.1-.8 2-1.8 2zm6.8 0c-1 0-1.8-.9-1.8-2s.8-2 1.8-2 1.9.9 1.8 2c0 1.1-.8 2-1.8 2z"></path></svg></a>
        </div>
      </div>

      <div>
        <h4>Explore</h4>
        <ul>
          <li><a href="#games">Slots</a></li>
          <li><a href="#jackpot">Jackpot</a></li>
          <li><a href="#faq">FAQ</a></li>
          <li><a href="#cta">VIP Club</a></li>
        </ul>
      </div>

      <div>
        <h4>Support</h4>
        <ul>
          <li><a href="#">Live Chat</a></li>
          <li><a href="#">Help Center</a></li>
          <li><a href="#">Responsible Play</a></li>
          <li><a href="#">Contact Us</a></li>
        </ul>
      </div>

      <div>
        <h4>Payment Methods</h4>
        <div class="payment-row">
          <span>Visa</span><span>Mastercard</span><span>Apple Pay</span><span>Bank Transfer</span><span>Crypto</span>
        </div>
      </div>
    </div>

    <div class="footer-bottom">
      <div><span class="age-badge">18+</span>Play responsibly. This is a design template — no real-money gambling occurs here.</div>
      <div>© 2026 LuckySpin. All rights reserved.</div>
    </div>
  </div>
</footer>

<script>
  // Mobile nav toggle
  const navToggle = document.getElementById('navToggle');
  const navLinks = document.getElementById('navLinks');
  navToggle.addEventListener('click', () => {
    const open = navLinks.classList.toggle('open');
    document.body.classList.toggle('nav-open', open);
    navToggle.setAttribute('aria-expanded', open);
  });
  navLinks.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
    navLinks.classList.remove('open');
    document.body.classList.remove('nav-open');
  }));

  // Jackpot countdown — counts down to the next local midnight
  function updateCountdown(){
    const now = new Date();
    const next = new Date(now);
    next.setHours(24,0,0,0);
    const diff = Math.max(0, next - now);
    const h = Math.floor(diff / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    const s = Math.floor((diff % 60000) / 1000);
    document.getElementById('cdHours').textContent = String(h).padStart(2,'0');
    document.getElementById('cdMins').textContent = String(m).padStart(2,'0');
    document.getElementById('cdSecs').textContent = String(s).padStart(2,'0');
  }
  updateCountdown();
  setInterval(updateCountdown, 1000);
</script>
</body>
</html>
